import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/status-badge";
import { useToast } from "@/hooks/use-toast";
import { Phone, FileText, CalendarDays, ArrowRight, Sparkles, Loader2, Plane } from "lucide-react";
import type { CallRequest, ItineraryProposal } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: callRequests, isLoading: loadingCalls } = useQuery<CallRequest[]>({
    queryKey: ["/api/call-requests"],
  });
  const { data: proposals, isLoading: loadingProposals } = useQuery<ItineraryProposal[]>({
    queryKey: ["/api/proposals"],
  });

  const seedMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/seed-demo");
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      toast({ title: "Demo data loaded" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const isLoading = loadingCalls || loadingProposals;

  const upcomingTrips = callRequests?.filter(
    (c) => c.dateFrom && new Date(c.dateFrom) >= new Date(new Date().toDateString())
  ) || [];

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="font-serif text-2xl sm:text-3xl font-bold" data-testid="text-dashboard-greeting">
          Welcome back, {user?.firstName}
        </h1>
        <p className="text-muted-foreground mt-1">Here's what's happening with your travel plans.</p>
      </div>

      <div>
        <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
          <h2 className="font-semibold text-lg">Proposals</h2>
          <Link href="/proposals">
            <Button variant="ghost" size="sm" data-testid="link-view-all-proposals">
              View All <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </Link>
        </div>
        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4"><Skeleton className="h-4 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></Card>
            ))}
          </div>
        ) : proposals && proposals.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {proposals.map((p) => (
              <Link key={p.id} href={`/proposals/${p.id}`}>
                <Card className="p-4 hover-elevate cursor-pointer h-full" data-testid={`card-proposal-${p.id}`}>
                  <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                    <span className="font-medium" data-testid={`text-proposal-title-${p.id}`}>{p.title}</span>
                    <StatusBadge status={p.status} />
                  </div>
                  {p.summary && (
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{p.summary}</p>
                  )}
                  <p className="text-sm font-medium" data-testid={`text-proposal-estimate-${p.id}`}>
                    ${Number(p.totalEstimate).toLocaleString()}
                  </p>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <Card className="p-6 text-center">
            <FileText className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground mb-3">No proposals yet</p>
            <Link href="/request-call">
              <Button variant="outline" size="sm" data-testid="button-first-proposal">
                Request a Call to Get Started
                <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </Card>
        )}
      </div>

      <div>
        <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
          <h2 className="font-semibold text-lg">Upcoming Trips</h2>
          <Link href="/calendar">
            <Button variant="ghost" size="sm" data-testid="link-view-calendar">
              Calendar <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </Link>
        </div>
        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2].map((i) => (
              <Card key={i} className="p-4"><Skeleton className="h-4 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></Card>
            ))}
          </div>
        ) : upcomingTrips.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingTrips.map((trip) => {
              const matchingProposal = proposals?.find((p) => p.callRequestId === trip.id);
              const href = matchingProposal ? `/proposals/${matchingProposal.id}` : "/call-history";
              return (
                <Link key={trip.id} href={href}>
                  <Card className="p-4 hover-elevate cursor-pointer h-full" data-testid={`card-trip-${trip.id}`}>
                    <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <Plane className="w-4 h-4 text-primary" />
                        <span className="font-medium" data-testid={`text-trip-destination-${trip.id}`}>{trip.destination}</span>
                      </div>
                      <StatusBadge status={trip.status} />
                    </div>
                    <p className="text-sm text-muted-foreground" data-testid={`text-trip-dates-${trip.id}`}>
                      {trip.dateFrom} — {trip.dateTo}
                    </p>
                    {matchingProposal && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Proposal: {matchingProposal.title}
                      </p>
                    )}
                  </Card>
                </Link>
              );
            })}
          </div>
        ) : (
          <Card className="p-6 text-center">
            <CalendarDays className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground mb-3">No upcoming trips</p>
            <Link href="/request-call">
              <Button variant="outline" size="sm" data-testid="button-first-trip">
                Plan a Trip
                <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </Card>
        )}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
          <h3 className="font-semibold">Quick Actions</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => seedMutation.mutate()}
            disabled={seedMutation.isPending}
            data-testid="button-load-demo"
          >
            {seedMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Sparkles className="w-3 h-3 mr-1" />}
            Load Demo Data
          </Button>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          <Link href="/request-call">
            <Button variant="outline" className="w-full justify-start" data-testid="button-quick-request-call">
              <Phone className="w-4 h-4 mr-2" /> Request a Call
            </Button>
          </Link>
          <Link href="/profile">
            <Button variant="outline" className="w-full justify-start" data-testid="button-quick-edit-profile">
              <FileText className="w-4 h-4 mr-2" /> Edit Profile
            </Button>
          </Link>
          <Link href="/calendar">
            <Button variant="outline" className="w-full justify-start" data-testid="button-quick-view-calendar">
              <CalendarDays className="w-4 h-4 mr-2" /> View Calendar
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
}
