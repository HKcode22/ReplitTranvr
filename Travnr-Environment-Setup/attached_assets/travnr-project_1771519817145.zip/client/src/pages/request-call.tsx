import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Send, Loader2 } from "lucide-react";

const callRequestSchema = z.object({
  tripType: z.enum(["flight", "hotel", "both"]),
  destination: z.string().min(1, "Destination is required"),
  phone: z.string().min(7, "Phone number is required"),
  dateFrom: z.string().optional().default(""),
  dateTo: z.string().optional().default(""),
  flexibility: z.string().optional().default(""),
  timeWindow: z.string().optional().default(""),
  notes: z.string().optional().default(""),
});

type CallRequestFormValues = z.infer<typeof callRequestSchema>;

export default function RequestCallPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<CallRequestFormValues>({
    resolver: zodResolver(callRequestSchema),
    defaultValues: {
      tripType: "both", destination: "", phone: "", dateFrom: "", dateTo: "",
      flexibility: "", timeWindow: "", notes: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: CallRequestFormValues) => {
      await apiRequest("POST", "/api/call-requests", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/call-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({ title: "Call request submitted!" });
      setLocation("/call-history");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  return (
    <div className="p-4 sm:p-6 max-w-3xl mx-auto">
      <h1 className="font-serif text-2xl font-bold mb-1" data-testid="text-request-call-title">Request a Call</h1>
      <p className="text-muted-foreground text-sm mb-6">Tell us about your trip and we'll call you to plan it.</p>

      <Card className="p-5">
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <FormField control={form.control} name="tripType" render={({ field }) => (
              <FormItem><FormLabel>Trip Type</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl><SelectTrigger data-testid="select-trip-type"><SelectValue /></SelectTrigger></FormControl>
                  <SelectContent>
                    <SelectItem value="flight">Flight Only</SelectItem>
                    <SelectItem value="hotel">Hotel Only</SelectItem>
                    <SelectItem value="both">Flight + Hotel</SelectItem>
                  </SelectContent>
                </Select>
              <FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="destination" render={({ field }) => (
              <FormItem><FormLabel>Destination</FormLabel><FormControl><Input placeholder="e.g. Tokyo, Japan" {...field} data-testid="input-destination" /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="phone" render={({ field }) => (
              <FormItem><FormLabel>Phone Number</FormLabel><FormControl><Input type="tel" placeholder="+1 (555) 123-4567" {...field} data-testid="input-phone" /></FormControl><FormMessage /></FormItem>
            )} />
            <div className="grid sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="dateFrom" render={({ field }) => (
                <FormItem><FormLabel>From</FormLabel><FormControl><Input type="date" {...field} data-testid="input-date-from" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="dateTo" render={({ field }) => (
                <FormItem><FormLabel>To</FormLabel><FormControl><Input type="date" {...field} data-testid="input-date-to" /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="flexibility" render={({ field }) => (
                <FormItem><FormLabel>Flexibility</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger data-testid="select-flexibility"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="Exact dates">Exact dates</SelectItem>
                      <SelectItem value="1-2 days">1-2 days</SelectItem>
                      <SelectItem value="Up to a week">Up to a week</SelectItem>
                      <SelectItem value="Very flexible">Very flexible</SelectItem>
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="timeWindow" render={({ field }) => (
                <FormItem><FormLabel>Best Time to Call</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger data-testid="select-time-window"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="Morning (9am-12pm)">Morning (9am-12pm)</SelectItem>
                      <SelectItem value="Afternoon (12-5pm)">Afternoon (12-5pm)</SelectItem>
                      <SelectItem value="Evening (5-8pm)">Evening (5-8pm)</SelectItem>
                      <SelectItem value="Anytime">Anytime</SelectItem>
                    </SelectContent>
                  </Select>
                <FormMessage /></FormItem>
              )} />
            </div>
            <FormField control={form.control} name="notes" render={({ field }) => (
              <FormItem><FormLabel>Additional Notes</FormLabel><FormControl><Textarea placeholder="Any specific requests or preferences..." {...field} data-testid="input-call-notes" /></FormControl><FormMessage /></FormItem>
            )} />
            <Button disabled={mutation.isPending} data-testid="button-submit-call-request">
              {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
              Submit Request
            </Button>
          </form>
        </Form>
      </Card>
    </div>
  );
}
